"""
-------------------------------------------------------
t01
-------------------------------------------------------
Author:  Cassel Robson
ID:      210507000
Email:   robs7000@mylaurier.ca
__updated__ = "2022-03-11"
-------------------------------------------------------
"""
# Imports

from Food_utilities import read_foods
from List_linked import List

file = open("food.txt", "rt")

foods = read_foods(file)

file.close()

lst = List()

for value in foods:
    lst.append(value)

print("Printing the first item: ")
print(lst[0])

lst.prepend(foods[10])

print()
print("Printing first item: ")
print(lst[0])

print()
print('Printing count of each item: ')
for value in lst:
    print(value.name, lst.count(value))

lst.clean()

print()
print('Printing count of each item: ')
for value in lst:
    print(value.name, lst.count(value))

lst2 = List()

lst3 = List()

for value in range(10):
    lst2.append(foods[value])

lst3.combine(lst, lst2)
print()
print("Printing count of each item in lst3: ")

for value in lst2:
    print(value.name, lst2.count(value))


print()
print("lst1 and lst2 are identical?: ")
print(lst.is_identical(lst2))


print()
print("Printing count of each item in lst3: ")
for value in lst3:
    print(value.name, lst3.count(value))


lst3.remove_many(foods[0])

print()
print("Printing count of each item in lst3: ")
for value in lst3:
    print(value.name, lst3.count(value))

target1, target2 = lst3.split()

print('pringint count of each item in target1:')
for value in target1:
    print(value.name, target1.count(value))

print('pringint count of each item in target2:')
for value in target2:
    print(value.name, target2.count(value))


target3, target4 = target1.split_alt()

print()
print("Printing count of each item in target3: ")
for value in target3:
    print(value.name, target3.count(value))

print('Printing count of each item in target4: ')
for value in target4:
    print(value.name, target4.count(value))


lst3.union(target3, target4)

print()
print('Printing count of each item in lst3')

for value in lst3:
    print(value.name, lst3.count(value))
